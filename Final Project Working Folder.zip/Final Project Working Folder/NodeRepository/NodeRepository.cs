﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NodeDB;

namespace NodeRepository
{

    public class NodeModel
    {
        public int NodeId { get; set; }
        public string NodeName { get; set; }
        public string Commodity { get; set; }
        public int Zone { get; set; }
        public string Type { get; set; }
        public int Priority { get; set; }
        public string Notes { get; set; }
        public System.DateTime CreatedDate { get; set; }
    }

    public class NodeRepository
    {
        public NodeModel Add(NodeModel nodeModel)
        {
            var nodeDb = ToDbModel(nodeModel);

            DatabaseManager.Instance.Nodes.Add(nodeDb);
            DatabaseManager.Instance.SaveChanges();

            nodeModel = new NodeModel
            {
                NodeId = nodeDb.NodeId,
                NodeName = nodeDb.NodeName,
                Commodity = nodeDb.Commodity,
                Zone = (int)nodeDb.Zone,
                Type = nodeDb.Type,
                Priority = (int)nodeDb.Priority,
                Notes = nodeDb.Notes,
                CreatedDate = nodeDb.CreatedDate
            };
            return nodeModel;
        }

        public List<NodeModel> GetAll()
        {
            // Use .Select() to map the database contacts to ContactModel
            var items = DatabaseManager.Instance.Nodes
              .Select(t => new NodeModel
              {
                  NodeId = t.NodeId,
                  NodeName = t.NodeName,
                  Commodity = t.Commodity,
                  Zone = (int)t.Zone,
                  Type = t.Type,
                  Priority = (int)t.Priority,
                  Notes = t.Notes,
                  CreatedDate = t.CreatedDate
              }).ToList();

            return items;
        }

        public bool Update(NodeModel contactModel)
        {
            var original = DatabaseManager.Instance.Nodes.Find(contactModel.NodeId);

            if (original != null)
            {
                DatabaseManager.Instance.Entry(original).CurrentValues.SetValues(ToDbModel(contactModel));
                DatabaseManager.Instance.SaveChanges();
                return true;
            }

            return false;
        }

        public bool Remove(int nodeId)
        {
            var items = DatabaseManager.Instance.Nodes
                                .Where(t => t.NodeId == nodeId);

            if (items.Count() == 0)
            {
                return false;
            }

            DatabaseManager.Instance.Nodes.Remove(items.First());
            DatabaseManager.Instance.SaveChanges();

            return true;
        }

        private Node ToDbModel(NodeModel nodeModel)
        {
            var contactDb = new Node
            {
                NodeId = nodeModel.NodeId,
                NodeName = nodeModel.NodeName,
                Commodity = nodeModel.Commodity,
                Zone = nodeModel.Zone,
                Type = nodeModel.Type,
                Priority = nodeModel.Priority,
                Notes = nodeModel.Notes,
                CreatedDate = nodeModel.CreatedDate
            };

            return contactDb;
        }
    }   

}
