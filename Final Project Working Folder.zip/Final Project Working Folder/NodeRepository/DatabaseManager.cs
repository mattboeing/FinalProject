﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NodeDB;

namespace NodeRepository
{
    public class DatabaseManager
    {
        private static readonly NodesEntities entities;

        // Initialize and open the database connection
        static DatabaseManager()
        {
            entities = new NodesEntities();
            entities.Database.Connection.Open();
        }

        // Provide an accessor to the database
        public static NodesEntities Instance
        {
            get
            {
                return entities;
            }
        }
    }
}
