﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FinalProject.Models;

namespace FinalProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public NodeModel Node { get; set; }

        public MainWindow()
        {
            InitializeComponent();

        }

        private void uxFileNew_Click(object sender, RoutedEventArgs e)
        {

        }

        private void uxFileChange_Click(object sender, RoutedEventArgs e)
        {

        }

        private void uxFileDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void uxFileDisplayAll_Click(object sender, RoutedEventArgs e)//doing things backwards..
        {
            //var window = new DisplayAllNodes();

            //if (window.ShowDialog() == true)
            //{
            //    var uiNodeModel = window.Node;

            //    var repositoryContactModel = uiNodeModel.ToRepositoryModel();

            //    App.NodeRepository.Add(repositoryContactModel);

            //    // OR
            //    //App.ContactRepository.Add(window.Contact.ToRepositoryModel());
            //}
        }

        private void uxFileChange_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void uxFileDelete_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void uxFileDisplayAll_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

        private void uxSubmit_Click(object sender, RoutedEventArgs e)
        {
            Node = new NodeModel();

            Node.NodeName = uxName.Text;
            Node.Commodity = uxCommodity.Text;
            Node.Zone = int.Parse(uxZone.Text);

            if (uxDoNeedLabel.IsChecked.Value)
            {
                Node.Type = "Needs Node Marker";
            }
            else
            {
                Node.Type = "Doesn't Need Node Marker";
            }


            Node.Priority = int.Parse(uxPriority.Text);
            Node.Notes = uxNotes.Text;
            Node.CreatedDate = DateTime.Now;

            // This section modified heavily..
            var repositoryContactModel = Node.ToRepositoryModel();
            App.NodeRepository.Add(repositoryContactModel);
            //

            // Clear contents?
            uxName.Clear();
            uxCommodity.Clear();
            uxZone.Clear();
            uxNotes.Clear();
            uxDoNeedLabel.IsChecked = true;
            uxPriority.Clear();
            //

            // This is the return value of ShowDialog( ) below
            //DialogResult = true;
            //Close();
        }

        private void uxCancel_Click(object sender, RoutedEventArgs e)
        {
            //DialogResult = false;
            uxName.Clear();
            uxCommodity.Clear();
            uxZone.Clear();
            uxNotes.Clear();
            uxDoNeedLabel.IsChecked = true;
            uxPriority.Clear();

            //Close();
        }
    }
}
