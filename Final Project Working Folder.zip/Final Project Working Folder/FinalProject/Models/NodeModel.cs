﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.Models
{
    public class NodeModel // Had to add the public identifier when writing MainWindow.xaml.cs
    {
        public int NodeId { get; set; }
        public string NodeName { get; set; }
        public string Commodity { get; set; }
        public Nullable<int> Zone { get; set; }
        public string Type { get; set; }
        public Nullable<int> Priority { get; set; }
        public string Notes { get; set; }
        public System.DateTime CreatedDate { get; set; }

        public NodeRepository.NodeModel ToRepositoryModel()
        {
            var repositoryModel = new NodeRepository.NodeModel
            {
                NodeId = NodeId,
                NodeName = NodeName,
                Commodity = Commodity,
                Zone = (int)Zone,
                Type = Type,
                Priority = (int)Priority,
                Notes = Notes,
                CreatedDate = CreatedDate,
            };

            return repositoryModel;
        }

        public static NodeModel ToModel(NodeRepository.NodeModel respositoryModel)
        {
            var nodeModel = new NodeModel
            {
                NodeId = respositoryModel.NodeId,
                NodeName = respositoryModel.NodeName,
                Commodity = respositoryModel.Commodity,
                Zone = (int)respositoryModel.Zone,
                Type = respositoryModel.Type,
                Priority = (int)respositoryModel.Priority,
                Notes = respositoryModel.Notes,
                CreatedDate = respositoryModel.CreatedDate,
            };

            return nodeModel;
        }
    }
}
