﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace FinalProject
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private static NodeRepository.NodeRepository nodeRepository;

        static App()
        {
            nodeRepository = new NodeRepository.NodeRepository();
        }

        public static NodeRepository.NodeRepository NodeRepository
        {
            get
            {
                return nodeRepository;
            }
        }
    }
}
