﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FinalProject.Models;

namespace FinalProject
{
    /// <summary>
    /// Interaction logic for DisplayAllNodes.xaml
    /// </summary>
    public partial class DisplayAllNodes : Window
    {

        public NodeModel Node { get; set; }

        public DisplayAllNodes()
        {
            InitializeComponent();
            ShowInTaskbar = false;
        }

        private void UxContactList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void uxContactList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
